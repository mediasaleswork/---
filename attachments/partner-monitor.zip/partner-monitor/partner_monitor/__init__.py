"""Monitor public Telegram partner channels without joining them."""
