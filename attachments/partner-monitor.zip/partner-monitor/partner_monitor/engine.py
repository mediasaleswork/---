from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
import re
import tempfile
from datetime import datetime, timedelta, timezone

from telethon import TelegramClient, errors, types

from .capture import Screenshotter
from .config import Config
from .parsing import PartnerReference, match_ad, parse_partner_references
from .storage import Store, utcnow

log = logging.getLogger(__name__)


def due_milestones(post: dict, existing: list[dict], hours: tuple[float, ...], now: datetime) -> list[tuple[str, str]]:
    done = {s["due_key"] for s in existing}
    published = datetime.fromisoformat(post["published_at"])
    first_seen = datetime.fromisoformat(post["first_seen_at"])
    result = []
    if "initial" not in done:
        result.append(("initial", first_seen.isoformat()))
    for h in hours:
        due = published + timedelta(hours=h)
        key = f"{h:g}h"
        # Never pretend that a historical 24-hour measurement can be recovered.
        if key not in done and first_seen < due <= now:
            result.append((key, due.isoformat()))
    return result


def client_for(config: Config) -> TelegramClient:
    config.data_dir.mkdir(parents=True, exist_ok=True)
    api_id, api_hash = config.telegram_credentials()
    return TelegramClient(str(config.data_dir / "telegram"), api_id, api_hash, flood_sleep_threshold=0)


class Monitor:
    def __init__(self, config: Config, store: Store, client, capture):
        self.config, self.store, self.client, self.capture = config, store, client, capture

    async def ingest_group(self):
        if not self.config.source_group:
            raise ValueError("Заполните source_group в config.yaml; команда dialogs покажет ID доступных групп")
        entity = await self.client.get_entity(self.config.source_group)
        if not (isinstance(entity, types.Chat) or isinstance(entity, types.Channel) and entity.megagroup):
            raise ValueError("source_group должен указывать на рабочую группу, а не на пользователя или канал")
        key = f"source_cursor:{entity.id}"
        cursor = int(self.store.state(key))
        options = {"min_id": cursor, "reverse": True, "limit": self.config.batch_size}
        if not cursor:
            options["offset_date"] = datetime.now(timezone.utc) - timedelta(days=self.config.lookback_days)
        async for message in self.client.iter_messages(entity, **options):
            text = message.message or ""
            urls = [e.url for e in message.entities or [] if isinstance(e, types.MessageEntityTextUrl)]
            refs = parse_partner_references(text, urls)
            document = getattr(message, "document", None)
            if document:
                name = next((a.file_name for a in document.attributes if isinstance(a, types.DocumentAttributeFilename)), "")
                extension = Path(name).suffix.lower()
                if extension in {".pdf", ".docx", ".xlsx"}:
                    try:
                        from .documents import extract_document
                        if document.size > 20 * 1024 * 1024:
                            raise ValueError("Размер документа превышает 20 МБ")
                        with tempfile.TemporaryDirectory(prefix="partner-document-") as scratch:
                            local = Path(scratch) / ("attachment" + extension)
                            await self.client.download_media(message, file=str(local))
                            extracted = await asyncio.to_thread(extract_document, local)
                        refs.extend(parse_partner_references(extracted))
                        if not refs:
                            self.store.add_review(entity.id, message.id, name, "В документе не найдена Telegram-ссылка; пришлите ссылку на канал отдельным сообщением")
                    except errors.FloodWaitError:
                        raise
                    except (OSError, ValueError) as exc:
                        self.store.add_review(entity.id, message.id, name, f"Документ не удалось прочитать ({type(exc).__name__}); требуется явная Telegram-ссылка")
            forwarded = getattr(message, "fwd_from", None)
            from_id = getattr(forwarded, "from_id", None)
            if isinstance(from_id, types.PeerChannel):
                try:
                    origin = await self.client.get_entity(from_id)
                    if getattr(origin, "broadcast", False):
                        username = getattr(origin, "username", None)
                        original_id = getattr(forwarded, "channel_post", None)
                        if username:
                            refs.append(PartnerReference(username.lower(), original_id, f"https://t.me/{username}"))
                        else:
                            refs.append(PartnerReference(None, original_id, f"https://t.me/c/{origin.id}/{original_id or 0}", True, origin.id))
                except errors.FloodWaitError:
                    raise
                except (ValueError, errors.RPCError):
                    log.warning("Не удалось определить источник пересланного сообщения %s; явные ссылки всё равно обработаны", message.id)
            for ref in refs:
                self.store.add_partner(ref, entity.id, message.id)
            if not refs and not document and re.search(r"партн[её]р|hamkor", text, re.IGNORECASE):
                self.store.add_review(entity.id, message.id, f"сообщение №{message.id}", "Партнёр упомянут без ссылки на Telegram-канал; требуется уточнение")
            self.store.set_state(key, message.id)

    async def album(self, entity, message) -> list:
        if not getattr(message, "grouped_id", None):
            return [message]
        neighbours = await self.client.get_messages(entity, ids=list(range(max(1, message.id - 9), message.id + 10)))
        return sorted([m for m in neighbours if m and getattr(m, "grouped_id", None) == message.grouped_id], key=lambda m: m.id) or [message]

    async def discover(self, partner: dict, entity):
        pending = self.store.rows("SELECT message_id FROM requested_posts WHERE partner_id=? AND done=0", (partner["id"],))
        for item in pending:
            message = await self.client.get_messages(entity, ids=item["message_id"])
            if message and isinstance(message, types.Message):
                members = await self.album(entity, message)
                self.store.save_post(partner["id"], members, "direct_link:ссылка из рабочей группы", partner["username"])
                self.store.execute("UPDATE requested_posts SET done=1 WHERE partner_id=? AND message_id=?", (partner["id"], item["message_id"]))
            else:
                self.store.execute("UPDATE partners SET last_error=? WHERE id=?", (f"Пост {item['message_id']} по прямой ссылке недоступен; повторим проверку", partner["id"]))
        cursor = partner["last_message_id"]
        options = {"min_id": cursor, "reverse": True, "limit": self.config.batch_size}
        if not cursor:
            options["offset_date"] = datetime.now(timezone.utc) - timedelta(days=self.config.lookback_days)
        seen = set()
        async for message in self.client.iter_messages(entity, **options):
            if isinstance(message, types.Message):
                key = getattr(message, "grouped_id", None) or f"m:{message.id}"
                if key not in seen:
                    seen.add(key)
                    members = await self.album(entity, message)
                    text = "\n".join((m.message or "") + " " + " ".join(e.url for e in m.entities or [] if isinstance(e, types.MessageEntityTextUrl)) for m in members)
                    match = match_ad(text, self.config.keywords, self.config.domains)
                    if match.matched:
                        self.store.save_post(partner["id"], members, match.reason, partner["username"])
            # Advance only after successful processing, so a failure is retried.
            self.store.execute("UPDATE partners SET last_message_id=? WHERE id=?", (message.id, partner["id"]))

    async def capture_snapshot(self, partner: dict, post: dict, snapshot: dict):
        try:
            result = await self.capture.capture(partner["username"], json.loads(post["message_ids"]), f"post-{post['id']}-snapshot-{snapshot['id']}")
            self.store.execute("""UPDATE snapshots SET screenshot_path=?,screenshot_status=?,screenshot_error=?,
              screenshot_at=?,capture_attempts=capture_attempts+1 WHERE id=?""",
              (result.path, result.status, result.error, utcnow() if result.path else None, snapshot["id"]))
        except Exception as exc:
            log.warning("Ошибка скриншота поста %s: %s", post["id"], type(exc).__name__)
            self.store.execute("UPDATE snapshots SET screenshot_status='error',screenshot_error=?,capture_attempts=capture_attempts+1 WHERE id=?", (type(exc).__name__, snapshot["id"]))

    async def measure(self, partner: dict, entity):
        for post in self.store.rows("SELECT * FROM posts WHERE partner_id=?", (partner["id"],)):
            existing = self.store.rows("SELECT * FROM snapshots WHERE post_id=?", (post["id"],))
            due = due_milestones(post, existing, self.config.milestones_hours, datetime.now(timezone.utc))
            retries = [s for s in existing if not s["screenshot_path"] and s["capture_attempts"] < 3]
            if not due and not retries:
                continue
            messages = await self.client.get_messages(entity, ids=json.loads(post["message_ids"]))
            available = [m for m in messages if isinstance(m, types.Message)]
            if len(available) != len(json.loads(post["message_ids"])):
                self.store.execute("UPDATE posts SET status='unavailable',last_error=? WHERE id=?", ("Не удалось получить все сообщения публикации; удаление не подтверждено", post["id"]))
                continue
            available.sort(key=lambda m: m.id)
            self.store.execute("UPDATE posts SET status='active',last_error=NULL,text=? WHERE id=?", ("\n".join(m.message or "" for m in available).strip(), post["id"]))
            # get_messages reads stored counters, without incrementing them via GetMessagesViews.
            views = getattr(available[0], "views", None)
            for key, due_at in due:
                self.store.execute("""INSERT OR IGNORE INTO snapshots(post_id,due_key,due_at,checked_at,views,screenshot_status)
                  VALUES (?,?,?,?,?,'pending')""", (post["id"], key, due_at, utcnow(), views))
                snapshot = self.store.rows("SELECT * FROM snapshots WHERE post_id=? AND due_key=?", (post["id"], key))[0]
                await self.capture_snapshot(partner, post, snapshot)
            for snapshot in retries:
                await self.capture_snapshot(partner, post, snapshot)

    async def tick(self):
        await self.ingest_group()
        for partner in self.store.rows("SELECT * FROM partners WHERE username IS NOT NULL AND status NOT IN ('private','ignored')"):
            try:
                entity = await self.client.get_entity(partner["username"])
                if not isinstance(entity, types.Channel) or not entity.broadcast:
                    self.store.execute("UPDATE partners SET status='ignored',last_error=? WHERE id=?", ("Ссылка ведёт на пользователя, бота или группу, а не на канал", partner["id"]))
                    continue
                if not getattr(entity, "username", None):
                    raise ValueError("Нет публичного username")
                if partner.get("channel_id") and partner["channel_id"] != entity.id:
                    self.store.execute("UPDATE partners SET status='identity_changed',last_error=? WHERE id=?", ("Username теперь принадлежит другому каналу. Нужна проверка партнёра", partner["id"]))
                    continue
                self.store.execute("UPDATE partners SET channel_id=?,title=?,status='active',last_error=NULL WHERE id=?", (entity.id, entity.title, partner["id"]))
                await self.discover(partner, entity)
                await self.measure(partner, entity)
            except errors.FloodWaitError:
                raise
            except (ValueError, errors.RPCError) as exc:
                self.store.execute("UPDATE partners SET status='unavailable',last_error=? WHERE id=?", (f"Не удалось проверить канал: {type(exc).__name__}", partner["id"]))
                log.warning("Канал @%s недоступен: %s", partner["username"], type(exc).__name__)
            await asyncio.sleep(1)


async def run(config: Config, *, once: bool = False):
    from .reports import export_xlsx

    client = client_for(config)
    await client.connect()
    try:
        if not await client.is_user_authorized():
            raise ValueError("Сначала выполните partner-monitor login на своём компьютере или сервере")
        with Store(config.db_path) as store:
            async with Screenshotter(config.data_dir / "screenshots") as capture:
                monitor = Monitor(config, store, client, capture)
                while True:
                    delay = config.interval_seconds
                    try:
                        await monitor.tick()
                        export_xlsx(*store.dump(), config.data_dir / "report.xlsx", timezone=config.timezone)
                        if config.google_credentials and config.spreadsheet_id:
                            try:
                                from .reports import GoogleReporter
                                reporter = GoogleReporter(config.google_credentials, config.spreadsheet_id, config.drive_folder_id, config.timezone)
                                uploaded = await asyncio.to_thread(reporter.sync, *store.dump())
                                for sid, url in uploaded.items():
                                    store.execute("UPDATE snapshots SET screenshot_url=? WHERE id=?", (url, int(sid)))
                            except Exception as exc:
                                log.warning("Google Sheets не синхронизирован (%s); локальный отчёт сохранён, повторим в следующем цикле", type(exc).__name__)
                        log.info("Цикл завершён. Отчёт: %s", config.data_dir / "report.xlsx")
                    except errors.FloodWaitError as exc:
                        delay = max(delay, exc.seconds + 1)
                        log.warning("Telegram запросил паузу %s секунд; продолжим после неё", exc.seconds)
                        if once:
                            raise ValueError(f"Telegram запросил паузу {exc.seconds} секунд; повторите позже") from exc
                    except (OSError, asyncio.TimeoutError, errors.ServerError, errors.RpcCallFailError, errors.TimedOutError) as exc:
                        log.warning("Временная ошибка соединения: %s; повторим цикл", type(exc).__name__)
                        if once:
                            raise
                    if once:
                        break
                    await asyncio.sleep(delay)
    finally:
        await client.disconnect()
