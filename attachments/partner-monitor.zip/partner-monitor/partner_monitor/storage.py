from __future__ import annotations

import json
import sqlite3
from contextlib import AbstractContextManager
from datetime import datetime, timezone
from pathlib import Path


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


class Store(AbstractContextManager):
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS partners (
          id INTEGER PRIMARY KEY, key TEXT NOT NULL UNIQUE, username TEXT, title TEXT,
          source_chat_id TEXT, source_message_id INTEGER, source_url TEXT,
          added_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active', last_error TEXT,
          last_message_id INTEGER NOT NULL DEFAULT 0, channel_id INTEGER);
        CREATE TABLE IF NOT EXISTS requested_posts (
          partner_id INTEGER REFERENCES partners(id), message_id INTEGER,
          done INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(partner_id,message_id));
        CREATE TABLE IF NOT EXISTS posts (
          id INTEGER PRIMARY KEY, partner_id INTEGER NOT NULL REFERENCES partners(id),
          album_key TEXT NOT NULL, message_id INTEGER NOT NULL, message_ids TEXT NOT NULL,
          url TEXT NOT NULL, published_at TEXT NOT NULL, first_seen_at TEXT NOT NULL,
          text TEXT NOT NULL, match_reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active',
          last_error TEXT, UNIQUE(partner_id,album_key));
        CREATE TABLE IF NOT EXISTS snapshots (
          id INTEGER PRIMARY KEY, post_id INTEGER NOT NULL REFERENCES posts(id),
          due_key TEXT NOT NULL, due_at TEXT NOT NULL, checked_at TEXT NOT NULL, views INTEGER,
          screenshot_path TEXT, screenshot_status TEXT NOT NULL, screenshot_error TEXT,
          screenshot_at TEXT, screenshot_url TEXT, capture_attempts INTEGER NOT NULL DEFAULT 0,
          UNIQUE(post_id,due_key));
        """)
        # Compatible with databases created by early versions of the MVP.
        if "channel_id" not in {r[1] for r in self.db.execute("PRAGMA table_info(partners)")}:
            self.execute("ALTER TABLE partners ADD COLUMN channel_id INTEGER")

    def __exit__(self, *args):
        self.db.close()

    def rows(self, sql: str, params=()) -> list[dict]:
        return [dict(r) for r in self.db.execute(sql, params)]

    def execute(self, sql: str, params=()):
        with self.db:
            return self.db.execute(sql, params)

    def state(self, key: str, default: str = "0") -> str:
        row = self.db.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
        return row[0] if row else default

    def set_state(self, key: str, value) -> None:
        self.execute("INSERT INTO state VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

    def add_partner(self, ref, chat_id: int | str, source_message_id: int) -> int:
        key = ref.username.lower() if ref.username else ref.source_url
        self.execute("""INSERT INTO partners(key,username,title,source_chat_id,source_message_id,source_url,added_at,status,last_error)
          VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(key) DO NOTHING""",
          (key, ref.username, ref.username or ref.source_url, str(chat_id), source_message_id, ref.source_url, utcnow(),
           "private" if ref.private else "active", "Закрытый канал: автоматическое вступление отключено" if ref.private else None))
        pid = self.rows("SELECT id FROM partners WHERE key=?", (key,))[0]["id"]
        if ref.message_id and not ref.private:
            self.execute("INSERT OR IGNORE INTO requested_posts(partner_id,message_id) VALUES (?,?)", (pid, ref.message_id))
        return pid

    def save_post(self, partner_id: int, messages: list, reason: str, username: str) -> int:
        messages = sorted(messages, key=lambda m: m.id)
        anchor = messages[0]
        album_key = f"g:{anchor.grouped_id}" if getattr(anchor, "grouped_id", None) else f"m:{anchor.id}"
        text = "\n".join(m.message or "" for m in messages).strip()
        ids = json.dumps([m.id for m in messages])
        self.execute("""INSERT INTO posts(partner_id,album_key,message_id,message_ids,url,published_at,first_seen_at,text,match_reason)
          VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(partner_id,album_key) DO UPDATE SET
          message_ids=excluded.message_ids,text=excluded.text,
          message_id=excluded.message_id,url=excluded.url,published_at=excluded.published_at,
          match_reason=CASE WHEN posts.match_reason LIKE 'manual:%' THEN posts.match_reason ELSE excluded.match_reason END""",
          (partner_id, album_key, anchor.id, ids, f"https://t.me/{username}/{anchor.id}", anchor.date.isoformat(), utcnow(), text, reason))
        return self.rows("SELECT id FROM posts WHERE partner_id=? AND album_key=?", (partner_id, album_key))[0]["id"]

    def add_review(self, chat_id: int | str, message_id: int, filename: str, reason: str):
        self.execute("""INSERT INTO partners(key,title,source_chat_id,source_message_id,added_at,status,last_error)
          VALUES (?,?,?,?,?,'needs_review',?) ON CONFLICT(key) DO UPDATE SET last_error=excluded.last_error""",
          (f"review:{chat_id}:{message_id}", f"Уточнить канал: {filename[:160]}", str(chat_id), message_id, utcnow(), reason))

    def dump(self) -> tuple[list[dict], list[dict], list[dict]]:
        return (self.rows("SELECT * FROM partners ORDER BY id"), self.rows("SELECT * FROM posts ORDER BY published_at,id"),
                self.rows("SELECT * FROM snapshots ORDER BY checked_at,id"))
